function error = testStep(CTLR, step, Pfunction)
    params = Pfunction(step);
    
end